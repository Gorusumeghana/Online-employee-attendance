<?php
	$conn = new mysqli('localhost', 'root', '', 'attendence') or die(mysqli_error());